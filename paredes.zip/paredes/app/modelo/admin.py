from django.contrib import admin
from .models import Producto

class AdminProducto(admin.ModelAdmin):
	list_display = ["clave", "nombreProducto", "localVenta", "direccion",
		"telefono", "fechaElaboracion"]
	list_editable= ["nombreProducto", "telefono"]
	list_filter= ["clave", "nombreProducto", "localVenta", "fechaElaboracion"]

	class Meta:
		model = Producto

admin.site.register(Producto,AdminProducto)
