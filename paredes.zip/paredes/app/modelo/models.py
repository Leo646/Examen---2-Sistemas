
from django.db import models
from django.contrib.auth import get_user_model
from django.core.validators import MaxValueValidator


class Producto(models.Model):

	clave = models.CharField('clave', max_length = 25, unique = True)
	nombreProducto = models.CharField('nombreProducto', max_length = 25, blank=False, null=False)
	localVenta = models.CharField('localVenta', max_length = 25, blank=False, null=False)
	direccion = models.CharField('direccion', max_length = 25, blank=False, null=False)
	telefono = models.CharField(max_length = 10, blank=False, null=False)
	fechaElaboracion = models.DateField()

