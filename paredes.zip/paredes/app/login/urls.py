from django.urls import path
from . import views

urlpatterns = [
	path('', views.loginPage, name="autenticar"), #url para el login
	path('logoutPage', views.logoutPage, name="salir"), 
	
]
