from django import forms
from app.modelo.models import Producto

class FormularioLogin(forms.Form): 
	username = forms.CharField()
	password = forms.CharField(widget = forms.PasswordInput())
