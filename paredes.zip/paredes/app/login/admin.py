from django.contrib import admin

# Register your models here.
class LoginConfig(AppConfig):
    name = 'login'
