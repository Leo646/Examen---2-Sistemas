from django.shortcuts import render, redirect 
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required

from .forms import FormularioProducto

from app.modelo.models import Producto
from django.template import Library


@login_required
def principal(request):
	lista = Producto.objects.all()
	context = {
		'l': lista,
	}
	return render(request, 'productos/principal_producto.html',context) 

def crear(request):
	formulario = FormularioProducto(request.POST) 
	if request.method == 'POST':
		if formulario.is_valid():
			datos = formulario.cleaned_data 
			producto = Producto() 
			producto.clave = datos.get('clave')
			producto.nombreProducto = datos.get('nombreProducto')
			producto.localVenta = datos.get('localVenta')
			producto.direccion = datos.get('direccion')
			producto.telefono = datos.get('telefono')
			producto.fechaElaboracion = datos.get('fechaElaboracion')
			producto.save()
			return redirect(principal)

	context = { 
		'f': formulario
	}
	return render(request, 'productos/crear_producto.html', context)


