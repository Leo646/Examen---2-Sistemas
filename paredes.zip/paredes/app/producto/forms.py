from django import forms
from app.modelo.models import Producto

class FormularioProducto(forms.ModelForm): 
	class Meta:
		model = Producto
		fields = ["clave", "nombreProducto", "localVenta", "direccion",
		"telefono", "fechaElaboracion"]


